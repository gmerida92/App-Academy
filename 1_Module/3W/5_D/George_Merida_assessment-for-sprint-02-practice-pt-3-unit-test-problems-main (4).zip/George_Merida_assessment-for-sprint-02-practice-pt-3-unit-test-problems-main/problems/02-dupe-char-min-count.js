/***********************************************************************
Write a function `duplicateCharMinCount(string, minCount)` that will take
a string as an argument and returns an array of characters that show up
at least `minCount` number of times. The string will have at least one
character.

Examples:

duplicateCharMinCount("apple", 2) // ["p"]
duplicateCharMinCount("banana", 2) // ["a", "n"]
duplicateCharMinCount("What about a longer string?", 3) // ["a", "t", " "]
***********************************************************************/

// function countCharacters(string) {
	let count = 0;
	let spreadString = [...string];



// }

// function duplicateCharMinCount(string, minCount) {
// }

// for(let i = 1; i < string.length; i++)
// {
// 	let j = i - 1;

// 	let currentchar = string[i];
// 	for( j = i + 1; j < )
// 	{
// 		let nextChar = string[j]
// 	}
// }

// let string = "apple"
// let spreadString = [...string];

// console.log(spreadString);

/*
	I want to take my string
	break it up into intividual letters and spaces
	take the first char and parse throught the next chars
	I need it to compare the current char with the following char
		if they are the same take a count
	once finished taking count, compare the count to the minCount
 */

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
// module.exports = duplicateCharMinCount;
